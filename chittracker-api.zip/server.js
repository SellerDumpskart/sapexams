const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = 3001;
const DATA_DIR = '/var/www/chittracker-data';

app.use(express.json({limit:'10mb'}));

// CORS - only allow from dumpskart.com
app.use((req,res,next)=>{
  res.header('Access-Control-Allow-Origin','https://dumpskart.com');
  res.header('Access-Control-Allow-Methods','GET,POST,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers','Content-Type,X-Auth-Token');
  if(req.method==='OPTIONS')return res.sendStatus(200);
  next();
});

// Helper: safe filename from key
const safeFile=(key)=>{
  const safe=key.replace(/[^a-zA-Z0-9_\-]/g,'_');
  return path.join(DATA_DIR, safe+'.json');
};

// GET /api/storage/:key
app.get('/api/storage/:key', (req,res)=>{
  try{
    const file=safeFile(req.params.key);
    if(!fs.existsSync(file))return res.json({exists:false,value:null});
    const value=fs.readFileSync(file,'utf8');
    res.json({exists:true,key:req.params.key,value});
  }catch(e){
    res.status(500).json({error:e.message});
  }
});

// POST /api/storage/:key  body: {value: "..."}
app.post('/api/storage/:key', (req,res)=>{
  try{
    const file=safeFile(req.params.key);
    fs.writeFileSync(file, req.body.value, 'utf8');
    res.json({ok:true,key:req.params.key});
  }catch(e){
    res.status(500).json({error:e.message});
  }
});

// DELETE /api/storage/:key
app.delete('/api/storage/:key', (req,res)=>{
  try{
    const file=safeFile(req.params.key);
    if(fs.existsSync(file))fs.unlinkSync(file);
    res.json({ok:true,deleted:req.params.key});
  }catch(e){
    res.status(500).json({error:e.message});
  }
});

// GET /api/storage  ?prefix=ct-  (list keys)
app.get('/api/storage', (req,res)=>{
  try{
    const prefix=req.query.prefix||'';
    const files=fs.readdirSync(DATA_DIR)
      .filter(f=>f.endsWith('.json'))
      .map(f=>f.replace('.json','').replace(/_/g,(m,i,s)=>{
        // Reverse the safe encoding - but we just list filenames
        return '_';
      }));
    // Return raw filenames as keys
    const keys=fs.readdirSync(DATA_DIR)
      .filter(f=>f.endsWith('.json'))
      .map(f=>f.slice(0,-5)); // remove .json
    res.json({keys});
  }catch(e){
    res.status(500).json({error:e.message});
  }
});

// Health check
app.get('/api/health', (req,res)=>res.json({ok:true,uptime:process.uptime()}));

app.listen(PORT, '127.0.0.1', ()=>{
  console.log(`ChitTracker API running on port ${PORT}`);
  console.log(`Data dir: ${DATA_DIR}`);
});
